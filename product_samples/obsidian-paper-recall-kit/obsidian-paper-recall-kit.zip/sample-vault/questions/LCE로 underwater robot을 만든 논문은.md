---
type: question
status: open
tags:
  - question
  - lce
---

# LCE로 underwater robot을 만든 논문은?

## 바로 볼 논문

- [[2020-christianson-lce-underwater-soft-robot]]

## 관련 개념

- [[Liquid Crystal Elastomer]]
- [[Soft Robot]]
- [[Thermal Actuation]]

## 지금까지의 답

LCE 필름의 열 반응을 이용해 물속에서 주기적인 bending locomotion을 만든 논문이 있다.
soft robot에서 재료의 anisotropic response가 운동 메커니즘으로 이어지는 예시로 다시 볼 만하다.

## 더 찾아볼 것

- LCE 기반 underwater locomotion 후속 논문
- dielectric elastomer actuator와 비교되는 soft robot 사례

## 검색 키워드

- LCE underwater locomotion
- liquid crystal elastomer soft robot
- thermal actuation swimmer
