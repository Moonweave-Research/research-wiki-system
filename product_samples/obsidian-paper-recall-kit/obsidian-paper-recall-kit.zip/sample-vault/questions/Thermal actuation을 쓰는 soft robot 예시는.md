---
type: question
status: open
tags:
  - question
  - soft-robot
---

# Thermal actuation을 쓰는 soft robot 예시는?

## 바로 볼 논문

- [[2020-christianson-lce-underwater-soft-robot]]

## 관련 개념

- [[Thermal Actuation]]
- [[Soft Robot]]
- [[Liquid Crystal Elastomer]]

## 지금까지의 답

LCE 필름처럼 온도 변화에 따라 곡률이 바뀌는 재료를 이용하면 soft robot의 반복 운동을 만들 수 있다.

## 더 찾아볼 것

- hydrogel 기반 thermal actuator
- shape memory polymer 기반 soft robot
- light-to-heat 변환을 쓰는 soft actuator
